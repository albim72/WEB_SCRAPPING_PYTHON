Zestaw plików do ćwiczeń web scraping / pobieranie załączników.
