// Mobile menu toggle
const menuToggle = document.getElementById('menuToggle');
const nav = document.getElementById('nav');
menuToggle?.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});

// Canvas demo
const canvas = document.getElementById('demoCanvas');
if (canvas && canvas.getContext) {
  const ctx = canvas.getContext('2d');
  const w = canvas.width, h = canvas.height;
  const grad = ctx.createLinearGradient(0,0,w,h);
  grad.addColorStop(0, '#0ea5e9');
  grad.addColorStop(1, '#14b8a6');
  ctx.fillStyle = grad;
  ctx.fillRect(0,0,w,h);
  ctx.fillStyle = 'rgba(255,255,255,.9)';
  ctx.font = '20px system-ui, sans-serif';
  ctx.fillText('Canvas demo', 20, 40);
}

// Dialog
const dlg = document.getElementById('dlg');
document.getElementById('openDlg')?.addEventListener('click', () => dlg.showModal());

// Template
document.getElementById('addTpl')?.addEventListener('click', () => {
  const tpl = document.getElementById('rowTpl');
  const list = document.getElementById('tplList');
  list.appendChild(tpl.content.cloneNode(true));
});

// ARIA pressed toggle
const ariaBtn = document.getElementById('ariaBtn');
ariaBtn?.addEventListener('click', () => {
  const pressed = ariaBtn.getAttribute('aria-pressed') === 'true';
  ariaBtn.setAttribute('aria-pressed', String(!pressed));
});

// Current year
document.getElementById('year').textContent = String(new Date().getFullYear());
